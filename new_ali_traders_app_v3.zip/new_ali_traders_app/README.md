# NEW ALI TRADERS – V3

V3 adds the core bill workflow to the iOS-26-style glass UI:

- Customer ledger with due balance
- Bill number generation
- Quantity × rate calculation
- Finger signature capture
- PDF invoice generation with signature
- Android share sheet (WhatsApp can be selected)
- Local persistent data using SharedPreferences
- Payment entry and due reduction
- Stock quantity reduction when a bill is saved

## Build

This is a Flutter source project. On a machine with Flutter installed:

    flutter pub get
    flutter build apk --release

The resulting APK is under `build/app/outputs/flutter-apk/app-release.apk`.

Note: direct WhatsApp sending is intentionally handled through Android's share sheet so the user can choose WhatsApp and the recipient safely.
